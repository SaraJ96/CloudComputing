using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.ServiceModel;
using System.Threading;
using System.Threading.Tasks;
using CloudService_Data.Helpers;
using CloudService_Data.Interfaces;
using Microsoft.WindowsAzure;
using Microsoft.WindowsAzure.Diagnostics;
using Microsoft.WindowsAzure.ServiceRuntime;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Queue;

namespace QueueRequestReceiver
{
    public class WorkerRole : RoleEntryPoint
    {
        private readonly CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();
        private readonly ManualResetEvent runCompleteEvent = new ManualResetEvent(false);

        public override void Run()
        {
            Trace.TraceInformation("QueueRequestReceiver is running");

            try
            {
                this.RunAsync(this.cancellationTokenSource.Token).Wait();
            }
            finally
            {
                this.runCompleteEvent.Set();
            }
        }

        public override bool OnStart()
        {
            Thread.Sleep(5000);
            // Set the maximum number of concurrent connections
            ServicePointManager.DefaultConnectionLimit = 12;

            // For information on handling configuration changes
            // see the MSDN topic at https://go.microsoft.com/fwlink/?LinkId=166357.

            bool result = base.OnStart();

           
            NetTcpBinding binding = new NetTcpBinding()
            {
                CloseTimeout = new TimeSpan(0, 10, 0),
                OpenTimeout = new TimeSpan(0, 10, 0),
                ReceiveTimeout = new TimeSpan(0, 10, 0),
                SendTimeout = new TimeSpan(0, 10, 0),
            };
            RoleInstanceEndpoint remoteInstanceEP = RoleEnvironment.Roles["WebRole"].Instances.First().InstanceEndpoints["InternalWebRequest"];
            String remoteAddress = $"net.tcp://{remoteInstanceEP.IPEndpoint}/InternalWebRequest";
            proxy = new ChannelFactory<IInternalWebRequest>(binding, remoteAddress).CreateChannel();

            Trace.TraceInformation("QueueRequestReceiver has been started");

            return result;
        }

        public override void OnStop()
        {
            Trace.TraceInformation("QueueRequestReceiver is stopping");

            this.cancellationTokenSource.Cancel();
            this.runCompleteEvent.WaitOne();

            base.OnStop();

            Trace.TraceInformation("QueueRequestReceiver has stopped");
        }
        IInternalWebRequest proxy;
        private async Task RunAsync(CancellationToken cancellationToken)
        {
            // TODO: Replace the following with your own logic.
            while (!cancellationToken.IsCancellationRequested)
            {
                CloudQueueMessage cloudQueueMessage = await QueueHelper.GetQueueReference("handlerqueue").GetMessageAsync();
                if (cloudQueueMessage != null)
                {
                    Trace.WriteLine("Preuzela iz reda poruku " + cloudQueueMessage.AsString);
                    await QueueHelper.GetQueueReference("handlerqueue").DeleteMessageAsync(cloudQueueMessage);
                    Trace.WriteLine("Obrisala poruku iz reda " + cloudQueueMessage.AsString);
                    proxy.ChangeHandler(cloudQueueMessage.AsString);
                }
                else
                {
                    Trace.WriteLine("Nema poruke u redu");
                }
                //Trace.TraceInformation("Working");
                await Task.Delay(1000);
            }
        }
    }
}
