﻿using CloudService_Data.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace EntityHandlerSelector
{
    class Program
    {
        static void Main(string[] args)
        {
            NetTcpBinding binding = new NetTcpBinding()
            {
                SendTimeout = new TimeSpan(0, 10, 0),
                OpenTimeout = new TimeSpan(0, 10, 0),
                CloseTimeout = new TimeSpan(0, 10, 0),
                ReceiveTimeout = new TimeSpan(0, 10, 0),

            };
            String remoteAddress = $"net.tcp://localhost:10100/InputRequest";

            IInputRequest proxy = new ChannelFactory<IInputRequest>(binding, remoteAddress).CreateChannel();

            Random r = new Random();
            try
            {
                while (true)
                {
                    if (r.Next(0, 1000) > 500)
                    {
                        proxy.Command("blue");
                        Console.WriteLine("Poslao blue");
                    }
                    else
                    {
                        proxy.Command("green");
                        Console.WriteLine("Poslao green");
                    }
                    Thread.Sleep(5000);
                }
            }
            catch
            {
                Console.WriteLine("Konekcija pukla, konzola zatvorena.");
            }
        }
    }
}
