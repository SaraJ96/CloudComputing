﻿using CloudService_Data.Classes;
using CloudService_Data.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.UI.WebControls.Expressions;
using WebRole.Models;

namespace WebRole.Controllers
{
    public class HomeController : Controller
    {
        
        public static string handler;
        static BindingModel BindingModel = new BindingModel();
        public ActionResult Index()
        {

            refresh();
            ViewBag.handler = handler;
            return View(BindingModel);
           
        }

        public ActionResult AddP(string serialNumber,string name,string manufacturer,int year)
        {
            MvcApplication.proxy.AddPhone(serialNumber, name, manufacturer, year);
            return RedirectToAction("Index");
        }

        public ActionResult AddS(string name, string address, string phoneNumber, string email)
        {
            MvcApplication.proxy.AddStore(name,address,phoneNumber,email);
            return RedirectToAction("Index");
        }
        public ActionResult DeleteP(string serialNumber)
        {
            MvcApplication.proxy.DeletePhone(serialNumber);
            return RedirectToAction("Index");
        }

        public ActionResult DeleteS(string name)
        {
            MvcApplication.proxy.DeleteStore(name);
            return RedirectToAction("Index");
        }

        [HttpPost]
        public ActionResult ReplaceP(string serialNumber, string name, string manufacturer, int year)
        {
            MvcApplication.proxy.ReplacePhone(serialNumber, name, manufacturer, year);
            return RedirectToAction("Index");
        }
        [HttpPost]
        public ActionResult ReplaceS(string name, string address, string phoneNumber, string email)
        {
            MvcApplication.proxy.ReplaceStore(name, address, phoneNumber, email);
            return RedirectToAction("Index");
        }

        private void refresh()
        {
            BindingModel.Phones = new List<Phone>();
            BindingModel.Stores = new List<Store>();
   
            foreach (var item in MvcApplication.proxy.GetAllPhones().Split('|'))
            {
                try
                {
                    BindingModel.Phones.Add(new Phone(item));
                }
                catch { }
            }

            foreach (var item in MvcApplication.proxy.GetAllStores().Split('|'))
            {
                try
                {
                    BindingModel.Stores.Add(new Store(item));
                }
                catch { }
            }
        }
    }
}