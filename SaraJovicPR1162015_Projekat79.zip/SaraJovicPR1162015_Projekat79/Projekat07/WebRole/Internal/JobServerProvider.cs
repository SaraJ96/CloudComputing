﻿using CloudService_Data.Helpers;
using CloudService_Data.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using WebRole.Controllers;

namespace WebRole.Internal
{
    public class JobServerProvider : IInternalWebRequest
    {
        BlobHelper blobHelper = new BlobHelper();
        public void ChangeHandler(string handler)
        {
            if (blobHelper.DownloadStringFromBlob($"{DateTime.Now.Day}_{DateTime.Now.Month}_{DateTime.Now.Year}") == "")
            {
                handler = "blue";
            }
            blobHelper.UploadStringToBlob($"{DateTime.Now.Day}_{DateTime.Now.Month}_{DateTime.Now.Year}", $"Stanje: {handler}, Vreme {DateTime.Now.ToShortTimeString()}");
            HomeController.handler = handler;
        }
    }
}