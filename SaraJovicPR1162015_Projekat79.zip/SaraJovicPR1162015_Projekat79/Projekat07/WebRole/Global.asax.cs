﻿using CloudService_Data.Interfaces;
using Microsoft.WindowsAzure.ServiceRuntime;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Web;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;
using WebRole.Internal;

namespace WebRole
{
    public class MvcApplication : System.Web.HttpApplication
    {
        JobServer js = new JobServer();
        internal static IEntityRequest proxy;
        protected void Application_Start()
        {
            js.Open();

            NetTcpBinding binding = new NetTcpBinding()
            {
                CloseTimeout = new TimeSpan(0, 10, 0),
                OpenTimeout = new TimeSpan(0, 10, 0),
                ReceiveTimeout = new TimeSpan(0, 10, 0),
                SendTimeout = new TimeSpan(0, 10, 0),
            };
            RoleInstanceEndpoint remoteInstanceEP = RoleEnvironment.Roles["EntityWorkerRole"].Instances.First().InstanceEndpoints["InternalRequest"];
            String remoteAddress = $"net.tcp://{remoteInstanceEP.IPEndpoint}/InternalRequest";
            proxy = new ChannelFactory<IEntityRequest>(binding, remoteAddress).CreateChannel();


            AreaRegistration.RegisterAllAreas();
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);
        }
    }
}
