﻿using CloudService_Data.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebRole.Models
{
    public class BindingModel
    {
        public List<Phone> Phones { get; set; }
        public List<Store> Stores { get; set; }
    }
}