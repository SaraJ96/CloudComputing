﻿using CloudService_Data.Classes;
using Microsoft.Azure;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Table;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CloudService_Data.Helpers
{
    public class TableHelper
    {
        private CloudTable table;
        private String partitionKey;

        public TableHelper(String tableName, String partitionKey)
        {
            CloudStorageAccount storageAccount = CloudStorageAccount.Parse(CloudConfigurationManager.GetSetting("DataConnectionString"));
            CloudTableClient tableClient = new CloudTableClient(new Uri(storageAccount.TableEndpoint.AbsoluteUri), storageAccount.Credentials);
            table = tableClient.GetTableReference(tableName);
            table.CreateIfNotExists();

            this.partitionKey = partitionKey;
        }


        public TableEntity GetEntitet(String value)
        {
            try
            {
                var results = from g in table.CreateQuery<TableEntity>()
                              where g.PartitionKey.Equals(partitionKey) && g.RowKey.Equals(value)
                              select g;
                return results.First();
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public List<Phone> GetAllPhones()
        {
            try
            {
                var results = from g in table.CreateQuery<Phone>()
                              where g.PartitionKey.Equals(partitionKey)
                              select g;
                return results.ToList();
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public List<Store> GetAlStores()
        {
            try
            {
                var results = from g in table.CreateQuery<Store>()
                              where g.PartitionKey.Equals(partitionKey)
                              select g;
                return results.ToList();
            }
            catch (Exception e)
            {
                throw e;
            }
        }



        public bool AddOrReplace(TableEntity entity)
        {
            try
            {
                TableOperation insertOrReplaceOperation = TableOperation.InsertOrReplace(entity);
                table.Execute(insertOrReplaceOperation);
                return true;
            }
            catch (Exception e)
            {
                Trace.TraceError($"ERROR: {e.Message}");
                return false;
            }
        }

        public bool Delete(string value)
        {
            try
            {
                TableEntity entity = GetEntitet(value);
                TableOperation deleteOperation = TableOperation.Delete(entity);
                table.Execute(deleteOperation);
                return true;
            }
            catch (Exception e)
            {
                Trace.TraceError($"ERROR: {e.Message}");
                return false;
            }
        }





    }
}
