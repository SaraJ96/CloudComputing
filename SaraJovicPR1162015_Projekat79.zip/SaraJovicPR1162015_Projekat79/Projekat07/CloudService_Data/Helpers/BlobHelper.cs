﻿using Microsoft.Azure;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Blob;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CloudService_Data.Helpers
{
    public class BlobHelper
    {
        static CloudBlobContainer container;

        public BlobHelper()
        {
            CloudStorageAccount storageAccount = CloudStorageAccount.Parse(CloudConfigurationManager.GetSetting("DataConnectionString"));

            CloudBlobClient blobClient = storageAccount.CreateCloudBlobClient();
            container = blobClient.GetContainerReference("handlercontainer");
            container.CreateIfNotExists();

            BlobContainerPermissions permissions = container.GetPermissions();
            permissions.PublicAccess = BlobContainerPublicAccessType.Container;
            container.SetPermissions(permissions);
        }

        
        public CloudBlockBlob UploadStringToBlob(String uniqueBlobName, String value)
        {
            CloudBlockBlob blob = null;

            using (var stream = new MemoryStream(Encoding.Default.GetBytes(value)))
            {
                try
                {
                    blob = container.GetBlockBlobReference(uniqueBlobName);
                    blob.UploadFromStream(stream);
                }
                catch (Exception e)
                {
                    throw e;
                }
            }
            return blob;
        }

        public String DownloadStringFromBlob(String uniqueBlobName)
        {
            String text = "";

            using (var stream = new MemoryStream())
            {
                try
                {
                    CloudBlockBlob blob = container.GetBlockBlobReference(uniqueBlobName);
                    blob.DownloadToStream(stream);
                    text = Encoding.Default.GetString(stream.ToArray());
                }
                catch (Exception)
                {

                }
            }
            return text;
        }
    }
}
