﻿using Microsoft.WindowsAzure.Storage.Table;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CloudService_Data.Classes
{
    public class Store: TableEntity
    {
        public Store(string name,string address, string phoneNumber, string email)
        {
            PartitionKey = "Store";
            RowKey = name;
            Address = address;
            PhoneNumber = phoneNumber;
            Email = email;
        }
        public Store() { }
        public Store(string store)
        {
            PartitionKey = store.Split(',')[0];
            RowKey = store.Split(',')[1];
            Address = store.Split(',')[2];
            PhoneNumber = store.Split(',')[3];
            Email = store.Split(',')[4];
        }

        public override string ToString()
        {
            return $"{PartitionKey},{RowKey},{Address},{PhoneNumber},{Email}";
        }

        public string Address { get; set; }
        public string PhoneNumber { get; set; }
        public string Email { get; set; }
    }
}
