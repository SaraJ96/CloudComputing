﻿using Microsoft.WindowsAzure.Storage.Table;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CloudService_Data.Classes
{
    public class Phone : TableEntity
    {
        public Phone(string serailNumber,string name, string manufacturer, int year)
        {
            PartitionKey = "Phone";
            RowKey = serailNumber;
            Name = name;
            Manufacturer = manufacturer;
            Year = year;
        }
        public Phone(string phone)
        {
            PartitionKey = phone.Split(',')[0];
            RowKey = phone.Split(',')[1];
            Name = phone.Split(',')[2];
            Manufacturer = phone.Split(',')[3];
            Year = int.Parse(phone.Split(',')[4]);
        }

        public override string ToString()
        {
            return $"{PartitionKey},{RowKey},{Name},{Manufacturer},{Year}";
        }

        public Phone() { }

        public string Name { get; set; }
        public string Manufacturer { get; set; }
        public int Year { get; set; }
    }
}
