﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace CloudService_Data.Interfaces
{
    [ServiceContract]
    public interface IInternalWebRequest
    {
        [OperationContract]
        void ChangeHandler(string handler);
    }
}
