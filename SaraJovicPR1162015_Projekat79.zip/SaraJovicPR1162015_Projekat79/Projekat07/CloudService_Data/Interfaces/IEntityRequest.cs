﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace CloudService_Data.Interfaces
{
    [ServiceContract]
    public interface IEntityRequest
    {
        [OperationContract]
        void AddPhone(string serialNumber,string name,string manufacturer,int year);

        [OperationContract]
        void DeletePhone(string serialNumber);

        [OperationContract]
        void ReplacePhone(string serialNumber, string name, string manufacturer,int year);

        [OperationContract]
        string GetAllPhones();



        [OperationContract]
        void AddStore(string name, string address, string phoneNumber, string email);

        [OperationContract]
        void DeleteStore(string name);

        [OperationContract]
        void ReplaceStore(string name, string address, string phoneNumber, string email);

        [OperationContract]
        string GetAllStores();
    }
}
