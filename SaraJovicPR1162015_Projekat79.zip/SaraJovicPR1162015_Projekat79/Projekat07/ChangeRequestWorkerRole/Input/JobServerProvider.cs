﻿using CloudService_Data.Helpers;
using CloudService_Data.Interfaces;
using Microsoft.WindowsAzure.Storage.Queue;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChangeRequestWorkerRole.Input
{
    class JobServerProvider : IInputRequest
    {
        public void Command(string value)
        {
            Trace.WriteLine($"Od konzole sam dobila " + value);
            CloudQueueMessage cloudQueueMessage = new CloudQueueMessage(value);
            QueueHelper.GetQueueReference("handlerqueue").AddMessage(cloudQueueMessage);
            Trace.WriteLine($"U red sam stavila poruku " + value);
        }
    }
}
