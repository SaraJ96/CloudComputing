﻿using CloudService_Data.Classes;
using CloudService_Data.Helpers;
using CloudService_Data.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;

namespace EntityWorkerRole.Internal
{
    class JobServerProvider : IEntityRequest
    {
        TableHelper phoneTable = new TableHelper("PhoneTable","Phone");
        TableHelper storeTable = new TableHelper("StoreTable", "Store");
        public void AddPhone(string serialNumber, string name, string manufacturer,int year)
        {
            Phone p = new Phone(serialNumber, name, manufacturer, year);
            phoneTable.AddOrReplace(p);
        }

        public void AddStore(string name, string address, string phoneNumber, string email)
        {
            Store s = new Store(name, address, phoneNumber, email);
            storeTable.AddOrReplace(s);
        }

        public void DeletePhone(string serialNumber)
        {
            phoneTable.Delete(serialNumber);
        }

        public void DeleteStore(string name)
        {
            storeTable.Delete(name);
        }

        public string GetAllPhones()
        {
            string phones = "";

            foreach (var item in phoneTable.GetAllPhones())
            {
                phones += item.ToString() + "|";
            }
            return phones;
        }

        public string GetAllStores()
        {
            string stores = "";

            foreach (var item in storeTable.GetAlStores())
            {
                stores += item.ToString()+"|";
            }
            return stores;
        }

        public void ReplacePhone(string serialNumber, string name, string manufacturer, int year)
        {
            Phone p = new Phone(serialNumber, name, manufacturer, year);
            phoneTable.AddOrReplace(p);
        }

        public void ReplaceStore(string name, string address, string phoneNumber, string email)
        {
            Store s = new Store(name, address, phoneNumber, email);
            storeTable.AddOrReplace(s);
        }
    }
}
